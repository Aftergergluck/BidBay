<?php
	require 'head_foot.php';
	headerHTML();
?>

<h1 class="Tpage">Enchères</h1>
	<br><br><br><br><br><br><br><br>
	<p>Voici la page d'Enchères</p>
	<br><br><br><br><br><br><br><br>

<?php
	//require 'headfoot.php';
	footerHTML();
?>