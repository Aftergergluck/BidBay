<?php
   function headerHTML()
   {
		session_cache_expire();		// peut être fonction session
		session_start();			// peut être fonction session
		echo "<!doctype html>";
		echo "<html>";
		echo "<head>";
		echo "<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"images/favicon.png\" />";
		echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />";
		echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"styles/template.css\">";
		echo "<title>BidBay</title>";
		echo "<div class=\"entete\"><a href=\"accueil.php\"><img class=\"logo\" src=\"images/logo.png\" alt=\"logo du site web\"/></a>";
		if(isset($_SESSION) && (!isset($_SESSION['login']) || ($_SESSION['login']=="Deco") || ($_SESSION['login']=="erreur") || ($_SESSION['login']=="manque"))) //Déconnecté
		{
			echo "<a class=\"bouton_inscr_head\" href=\"inscription.php\">Inscription</a>";
			echo "<a class=\"bouton_co_head\" href=\"connexion.php\">Connexion</a>";
		}
		else
		{
			$login = $_SESSION['login'];
			echo "<a class=\"deco\" href=\"deconnexion.php\">Déconnexion</a>";
			echo "<p class=\"mail\">Bienvenue sur BidBay : $login </p>";
		}
		echo "<form action=\"recherche.php\" method=\"post\" enctype=\"multipart/form-data\"><p class=\"rech\"></a>Recherche : <input type=\"text\" name=\"recherche\" placeholder=\"Votre recherche...\">  <input class=\"bouton_rech\" type=\"submit\" name=\"submit\" value=\"\" style=\"background-image:url(images/trouver-recherche.png)\" /></p></div></form>";
		echo "<nav style=\"text-align:center\">";
		echo "<a href=\"accueil.php\">Accueil</a>";
		echo "<a href=\"categories.php\">Catégories</a>";
		if(isset($_SESSION) && (!isset($_SESSION['login']) || ($_SESSION['login']=="Deco") || ($_SESSION['login']=="erreur") || ($_SESSION['login']=="manque"))) //Déconnecté
		{
			
			echo "<a href=\"connexion.php\">Vendre</a>";
			echo "<a href=\"connexion.php\">Mon Compte</a>";
		}
		else{
			echo "<a href=\"vendre.php\">Vendre</a>";
			echo "<a href=\"moncompte.php\">Mon Compte</a>";
		}
		echo "<a href=\"faq.php\">FAQ/Aide</a>";
		echo "</nav>";
		echo "</head>";
		echo "<body><section>";
   }
   
   function footerHTML()
   {
		echo "</section></body>";
		echo "<footer>";
		echo "<p>Projet Web BidBay © Copyright ~ Contact : administrateur@bidbay.fr<br>Aacha ~ Badens ~ Banquet ~ Daud ~ Guenat</p>";
		echo "</footer>";
		echo "</html>";
   }
   
?>		
